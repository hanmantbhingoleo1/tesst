package com.dclaimservice.claim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimSubmissionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimSubmissionServiceApplication.class, args);
	}

}
