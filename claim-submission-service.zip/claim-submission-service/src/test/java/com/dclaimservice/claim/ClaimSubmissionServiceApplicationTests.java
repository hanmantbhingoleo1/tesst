package com.dclaimservice.claim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimSubmissionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
